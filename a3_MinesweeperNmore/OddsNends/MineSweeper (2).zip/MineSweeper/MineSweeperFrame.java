//Jonathan Starkey


import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class MineSweeperFrame extends JFrame
{
	//Logic logic;
	GameBoard gameBoard;
	Container container;
	ScoreBar scoreBar;
	MineSweeperPanel mineSweeperPanel;
	Container c;
	Container c2;
	Logic logic;
	
	
	MineButton mineButton;
	
	public MineSweeperFrame()
	{
		setTitle("MineSweeper");
		Toolkit kit = Toolkit.getDefaultToolkit();
		Dimension screenSize = kit.getScreenSize();
		setSize(screenSize.width/2,screenSize.height/2);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		c = getContentPane();
		c.setLayout(new BorderLayout());
		Toolkit toolkit = Toolkit.getDefaultToolkit();
		
		
        Image im = toolkit.getImage("flag.jpg");
        im = im.getScaledInstance(20, 20, 0);
        ImageIcon imageIcon = new ImageIcon(im);
		
		Object[] temp2 = {"Yes","No im scared"};
		int temp = JOptionPane.showOptionDialog(null, "Are you ready?", "Minsweeper", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, temp2, temp2[0]);
		if(temp == 0)
		{
			
			logic = new Logic();
			gameBoard = new GameBoard();
			scoreBar = new ScoreBar(logic);
			//logic = new Logic();
			mineSweeperPanel = new MineSweeperPanel(logic,gameBoard,this, mineButton);
			
			c2 = new Container(); //found some example code on this on how to kind of add a scoreboard
			c2.setLayout(new BorderLayout());
			c2.add(scoreBar, BorderLayout.NORTH);
			c2.add(mineSweeperPanel, BorderLayout.CENTER);
			System.out.println("done");
			
			c.add(c2);
			setVisible(true);
		}
		if(temp == 1)
		{
			System.exit(0);
		}
		
		
       
		
	}
	public void gameOver(boolean result)
	{
		logic.loser = false;
		logic.winner = false;
		String sass ="";
		String title ="";
		if(result==false)
		{
			title = "YOUR TERRIBLE!";
			sass = "What even are you doing, you should just quit";
		}
		else if(result== true)
		{
			title = "Darn you beat me";
			sass = "This doesn't make you good. Wana play again?";
		}
		else 
		{
			title = "Broke! new game?";
			sass = "Pick something";
		}
		
		Object[] temp3 = {"Yes","No im scared"};
		int temp4 = JOptionPane.showOptionDialog(null, sass, title, JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, temp3, temp3[0]);
		if(temp4 ==0)
		{
			newGame();
			
		}
		if(temp4 == 1)
		{
			System.exit(0);
		}	
	}
	
	 public void newGame()
	{
		c2.remove(scoreBar);
		c2.remove(mineSweeperPanel);
		logic = new Logic();
		gameBoard = new GameBoard();
		scoreBar = new ScoreBar(logic);
		//logic = new Logic();
		MineSweeperPanel panel = new MineSweeperPanel(logic,gameBoard,this, mineButton);
		
		c2 = new Container(); //found some example code on this on how to kind of add a scoreboard
		c2.setLayout(new BorderLayout());
		c2.add(scoreBar, BorderLayout.NORTH);
		c2.add(panel, BorderLayout.CENTER);
		System.out.println("done");
		c.add(c2);
		setVisible(true);
			
	}
}