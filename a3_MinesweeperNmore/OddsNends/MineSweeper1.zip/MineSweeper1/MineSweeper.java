//Jonathan Starkey


import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;
public class MineSweeper 
{
	public static void main(String[] args)
	{
		new MineSweeperFrame();
	}
}