//Jonathan Starkey


import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class MineSweeperFrame extends JFrame
{
	//Logic logic;
	GameBoard gameBoard;
	Container container;
	Logic logic;
	MineButton mineButton;
	
	public MineSweeperFrame()
	{
		setTitle("MineSweeper");
		Toolkit kit = Toolkit.getDefaultToolkit();
		Dimension screenSize = kit.getScreenSize();
		setSize(screenSize.width/2,screenSize.height/2);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		Toolkit toolkit = Toolkit.getDefaultToolkit();
		
		/*
        Image im = toolkit.getImage("flag.jpg");
        im = im.getScaledInstance(20, 20, 0);
        ImageIcon imageIcon = new ImageIcon(im);
		*/
		Object[] temp2 = {"Yes"};
		int temp = JOptionPane.showOptionDialog(null, "Are you ready?", "Minsweeper", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, temp2, temp2[0]);
		if(temp == 0)
		{
			logic = new Logic();
			gameBoard = new GameBoard();
			System.out.println("done");
		}

        
		
		MineSweeperPanel panel = new MineSweeperPanel(logic,gameBoard,this, mineButton);
		c.add(panel);
		setVisible(true);
		// should i create a new game menu? 
		//container.add(MenuL(), BorderLayout.NORTH);
		
	}
	/*
	private JMenuBar menuBar()
	{
		;
		
	}
	
	private class MenuL implements ActionListener
	{
		;
	}*/

}