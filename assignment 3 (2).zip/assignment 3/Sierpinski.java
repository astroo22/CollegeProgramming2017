//Jonathan Starkey

public class Sierpinski
{
	public static void main(String[] args)
	{
		new SierpinskiFrame();
	}
}