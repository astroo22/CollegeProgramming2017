//Jonathan Starkey

public class Bottle
{
	public static void main(String[] args)
	{
		new MessageFrame();
	}
}