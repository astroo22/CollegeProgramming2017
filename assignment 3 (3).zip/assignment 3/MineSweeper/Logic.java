//Jonathan Starkey


import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// logic for the game
public class Logic
{
	//ok couple things i think im going to need here 
	// by guestimation ima say two variables that state if they are a winner or loser
	// looked at the assignment thing again could also use a bombs remaining variable 
	// since this is the logic pretty sure i need to call my gameboard here
	// so
	boolean winner = false;
	boolean loser = false;
	int bombsRemaining = 0;
	GameBoard gameBoard;
	MineButton mineButton;
	
	//ok first lets create the board
	public Logic()
	{
		this.gameBoard = createBoard();
	}
	public GameBoard createBoard()
	{
		return new GameBoard();
	}
	
	// need flag method
	public void addFlag(int r, int c)
	{
		
		gameBoard.setFlag(r,c);
		System.out.println("added flag");
			
		
		test();
		
	}
	// ok lets start with a clicked tile what happens?
	
	public void clickedTile(int r, int c)
	{
		if(gameBoard.hasBomb(r,c) == true)
		{
			loser = true;
			System.out.println("Loser");
			System.exit(0);
		}
		else if(gameBoard.hasCover(r,c) == true)
		{
			gameBoard.removeCover(r,c);
			
			//repaint();
			
		}
		
	}
	public void test()
	{
		bombsRemaining();
		winner = gameBoard.check();
	}
	public boolean lFlag(int r, int c)
	{
		if(gameBoard.hasFlag(r,c) == true)
		{
			return true;
		}
		else 
		{
			return false;
		}
	}
	/*
	public Tiles[][] getTiles(int r, int c)
	{
		return tiles1;
		
	}
	*/
	/*
	public MineButton getTile(int r, int c)
	{
		return mineButton(r,c);
	}*/
	
	public int getStatus(int r, int c)
	{
		
		if(gameBoard.hasFlag(r,c) == true)
		{
			return 1;
		}
		else if(gameBoard.hasCover(r,c) == true)
		{
			return 3;
		}
		
		else 
		{
			return gameBoard.getNumBombT(r,c);
		}
	}
	
	
	/*
	public void removeCover(int r, int c)
	{
		if(tiles1[r][c].hasBomb()== true)
		{
			
		}
		tiles1[r][c].setCover(false);
		
	}
	*/
	// thought there would be more stuff but only other thing i think i need is to find remaining bombs
	// you wanted it to be where you only really need to change one thing to get a different board size
	// so since this is rather far away from where that was specified uhhhh
	// something like gameBoard.tiles.length? and ill throw on a this in front if i have a compile error
	
	public void bombsRemaining()
	{
		int bombsFlagged = 0;
		for(int row = 0; row < this.gameBoard.s; row++)
		{
			for(int column = 0; column < this.gameBoard.s; column++)
			{
				if(this.gameBoard.getTile(row,column).hasBomb() && this.gameBoard.getTile(row,column).hasFlag())
				{
					bombsFlagged++;
				}
			}
		}
		bombsRemaining = gameBoard.s - bombsFlagged;
	}
	
}