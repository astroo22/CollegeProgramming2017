//Jonathan Starkey


import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;

public class MineButton extends JButton
{
	MineSweeperPanel mineSweeperPanel;
	GameBoard gameBoard;
	Logic logic;
	public int r;
	public int c;
	
	
	//public String text = "";
	private boolean bomb = false;
	private boolean flag = false;
	private boolean cover = true;
	//private Color currentColor;
	private int bombNum = 0;
	private Tiles tile;
	
	private int totalBombs = 20;
	//MouseThing mouseThing;
	public void MineButton(int r, int c, Logic logic,Tiles tile)
	{
		//this.setText(text);
		this.r = r;
		this.c = c;
		this.logic = logic;
		this.bomb = bomb;
		this.flag = flag;
		this.cover = cover;
		this.bombNum = gameBoard.getNumBombT(r,c);
		this.tile = gameBoard.getTile(r,c);
	}
	
	
	
	
	public void paintComponent(Graphics g)
	{
		//This is what i want to do
		
		super.paintComponent(g);
		
		if(logic.getStatus(r,c) == 1)
		{
			this.setText("F");
			
		}
		
		else if(logic.getStatus(r,c) == 3)
		{
			this.setText("?");
			
		}
		else 
		{
			this.setText("" + logic.getStatus(r,c));
		}
		
		/*
		if(this.hasFlag() == true)
		{
			//g.setText("F");
		}*/
		
	}
	/*
	public boolean hasBomb()
	{
		return bomb;
		
	}
	public boolean hasFlag()
	{
		return this.flag;
	}
	public boolean hasCover()
	{
		return this.cover;
	}
	public void removeFlag(boolean flag)
	{
		this.flag = false;
	}
	
	public void setFlag(boolean flag)
	{
		if(this.flag == true)
		{
			this.flag = false;
		}
		else 
		{
			this.flag = true;
		}
	}
	public void setBomb(boolean boom)
	{
		this.bomb = boom;
	}
	public void setCover(boolean covers)
	{
		this.cover = covers;
	}
	 public int getBombsTouching()
	{
		return bombNum;
	}
	public void setBombsTouching(int bombNum)
	{
		this.bombNum = bombNum;
	}*/
}
























/*
public class TheButtons extends MouseAdapter
{
	MineSweeperPanel mineSweeperPanel;
	public int r;
	public int c;
	public String text = "";
	private boolean bomb = false;
	private boolean flag = false;
	private boolean cover = true;
	private int bombNum = 0;
	private int totalBombs = 20;
	
	
	
	GameBoard gameBoard;
	
	public void theButtons(int r, int c)
	{
		this.text = text;
		this.r = r;
		this.c = c;
		this.bomb = gameBoard.tiles1[r][c].hasBomb();
		this.flag = gameBoard.tiles1[r][c].hasFlag();
		this.cover = gameBoard.tiles1[r][c].hasCover();
		this.bombNum = gameBoard.tiles1[r][c].getBombsTouching();
	}
	
	}
	public boolean hasBomb()
	{
		return bomb;
		
	}
	public boolean hasFlag()
	{
		return this.flag;
	}
	public boolean hasCover()
	{
		return this.cover;
	}
	
	public void setFlag(boolean flag)
	{
		this.flag = flag;
	}
	public void setBomb(boolean boom)
	{
		this.bomb = boom;
	}
	public void setCover(boolean covers)
	{
		this.cover = covers;
	}
	public int getBombsTouching()
	{
		return bombNum;
	}
	public void setBombsTouching(int bombNum)
	{
		this.bombNum = bombNum;
	}	
}
	
	

		
	
	/*
	
	public void paintCompoent(Graphics g)
	{
		super.paintComponent(g);
		g.setColor(Color.RED);
	} 
}
	
	
	
	
	
	
	
	/*
	new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						System.out.println("button: " + i + ii +" pressed");
						repaint();
					}
	*/
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*
	public void doButton(int r, int c)
	{
		mineSweeperPanel.Button[r][c].addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				System.out.println("button: " + r + c +" pressed");
				repaint();
			}
		});
		add(mineSweeperPanel.Button[r][c]);
	}
	
	
	public void MousePressed(MouseEvent e)
	{
		
		JButton Button = (JButton) e.getSource();
		if(gameBoard.tiles1[r][c].hasFlag())
		{
			mineSweeperPanel.Button[r][c].setText("F");
			repaint();
		}
		if(gameBoard.tiles1[r][c].hasCover())
		{
			mineSweeperPanel.Button[r][c].setBackground(Color.white);
			repaint();
		}
		else if(!gameBoard.tiles1[r][c].hasCover())
		{
			mineSweeperPanel.Button[r][c].setText("" +gameBoard.tiles1[r][c].getBombsTouching());
			repaint();
		}
		
	}
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		
	}

}*/