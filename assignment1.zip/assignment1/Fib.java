//Jonathan Starkey

import java.util.*;

public class Fib
{
	public static void main(String args[])
	{
		int n;
		
		n = Integer.parseInt(args[0]);
		
		int[] output = new int[n+1];
		for(int i = 0; i<=n; i++)
		{
			
			if(i>=2)
			{
				output[i] = (output[i-1] + output[i-2]);
			}
			else if (i==1)
			{
				output[i] = i;
				
			}
			else if (i==0)
			{
				output[i] = 0;
			}
			
		}
		System.out.println(output[n]);
	}
}