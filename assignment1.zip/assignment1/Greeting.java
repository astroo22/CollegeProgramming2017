//Jonathan Starkey

import java.util.*;

public class Greeting
{
	public static void main(String args[])
	{
		System.out.println("The keyboard is on fire");
		
	}
}	