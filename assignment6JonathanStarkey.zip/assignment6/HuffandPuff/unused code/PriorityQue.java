//jonathan Starkey

import java.util.*;
import java.io.*;

public class PriorityQue
{
	

}