package geography;
import java.io.*;
import java.net.*;
import java.util.*;

public class geographicMain
{
	public static void main(String args[])
	{
		System.out.println("I need something here so heres a monotone sentence containing my struggles");
	}

}