//Jonathan Starkey

import java.util.*;
/**
*Class that creates the evaluate function for Cos
*
*
*
*/
public class SinFunc extends Function
{
/**
* Method that evaluates sin for the given value
*
*/

	public double evaluate(double x)
	{
		return Math.sin(x);
	}
}